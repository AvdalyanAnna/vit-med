module.exports = [
    './gulp/tasks/html',
    './gulp/tasks/serve',
    './gulp/tasks/sass',
    './gulp/tasks/watch',
    './gulp/tasks/script',
    './gulp/tasks/img',
    './gulp/tasks/fonts',
    './gulp/tasks/svg'
];
